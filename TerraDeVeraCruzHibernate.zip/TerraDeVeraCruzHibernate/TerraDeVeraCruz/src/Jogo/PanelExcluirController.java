package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelExcluirController {
private PanelExcluir pe;
	
	
	public PanelExcluirController(PanelExcluir pe) {
		this.pe = pe;
	}
	
	public void inicializaController() {
		this.pe.getExcluirItem().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
	}
}
