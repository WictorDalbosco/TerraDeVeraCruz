package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelAtualizarController {
	private PanelAtualizar pa;
	
	
	public PanelAtualizarController(PanelAtualizar pa) {
		this.pa = pa;
	}
	
	public void inicializaController() {
		this.pa.getCriarItem().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
	}
}
