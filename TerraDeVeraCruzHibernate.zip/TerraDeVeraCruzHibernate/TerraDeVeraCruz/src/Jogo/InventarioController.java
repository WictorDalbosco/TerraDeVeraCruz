package Jogo;

import java.util.ArrayList;


public class InventarioController {
	private Slot slot;
	
	private ArrayList<Slot> slots;
	private PanelInventario inventario;
	private TelaJogo jogo;
	
	public InventarioController(ArrayList<Slot> slots, PanelInventario inventario, TelaJogo jogo) {
		super();
		this.slots = slots;
		this.inventario = inventario;
		this.jogo = jogo;
	}

	public void inicializaController() {
		inventario = new PanelInventario();
		
		jogo.addPanel(inventario.getPanel());
	}
	
	public void encerraController() {
		jogo.removePanel(inventario.getPanel());
	}
	
	
	

}
