package Jogo;

import org.hibernate.Session;

public class Principal {
	public static void main(String[] args) {
		/*
		 * TelaPause telaPause = new TelaPause(); PauseController pauseController = new
		 * PauseController(telaPause); pauseController.inicializaController();
		 
		TelaJogo jogo = new TelaJogo();
		JogoController jogoController = new JogoController(jogo);
		jogoController.inicializaController();	
		*/	
		Slot slot1 = new Slot(1,"P�o");
		Slot slot2 = new Slot(2,"Arroz");
		Slot slot3 = new Slot(3,"Feij�o");
		Slot slot4 = new Slot(4,"Luva de Couro");
		Inventario inventario = new Inventario();
		inventario.addSlot(slot1);
		inventario.addSlot(slot2);
		inventario.addSlot(slot3);
		inventario.addSlot(slot4);
		TelaCriacao tc = new TelaCriacao();
		CriacaoController criacaoController = new CriacaoController(tc,inventario);
		criacaoController.inicializaController();
		
		//Exemplo com DAO
		 Session session = HibernateAcesso.getSessionFactory().openSession();
		 SlotDAO dao = SlotDAO.getInstance(session);
		 
		 //Create
		 dao.save(slot1);
		 Slot result = dao.getById(slot1.getId());
		 System.out.println(result);
		 
		 //Retrieve
		 Slot result2 = dao.getById(slot1.getId());
		 System.out.println(result2); 
		 
		 //Update
		 slot1.setId(18480);
		 dao.merge(slot1);
		 Slot result3 = dao.getById(slot1.getId());
		 System.out.println(result3);
		 
		 /*//Delete
		dao.remove(aluno);
		try{
			Aluno result4 = dao.getById(aluno.getId());
		}catch(ObjectNotFoundException ex) {
			System.out.println("Aluno n�o encontrado!");
		}
		*/
		
	}
}
