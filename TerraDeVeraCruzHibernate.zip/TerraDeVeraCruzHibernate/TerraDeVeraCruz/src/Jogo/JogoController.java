package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class JogoController {
	private TelaJogo jogo;
	private boolean addedInvent;
	private PanelInventario inventario;
	private PanelPause pause;
	//private Usuario usuario;

	JogoController(TelaJogo jogo){
		this.jogo = jogo;
		//this.usuario = usuario;
	}
	
	public void inicializaController() {
		jogo.getFrame().addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent k) {
				System.out.println(k.getKeyChar() + " - " + k.getKeyCode());
				if(k.getKeyCode() == KeyEvent.VK_E) {
					if(inventario != null) {
						//jogo.getFrame().remove(iventario.getPanel());
						jogo.removePanel(inventario.getPanel());
						inventario = null;
						//System.out.println("Entrou no delete");
					}else {
						inventario = new PanelInventario();
						jogo.addPanel(inventario.getPanel());

						//System.out.println("Entrou no inserte");						
					}
					jogo.getFrame().repaint();
				}
				if(k.getKeyCode() == KeyEvent.VK_ESCAPE) {
					if(pause != null) {
						//jogo.getFrame().remove(iventario.getPanel());
						jogo.removePanel(pause.getPanel());
						pause = null;
						//System.out.println("Entrou no delete");
					}else {
						pause = new PanelPause();
						jogo.addPanel(pause.getPanel());
						PauseController pc = new PauseController(pause);
						pc.inicializaController();

						//System.out.println("Entrou no inserte");						
					}
					jogo.getFrame().repaint();
					
				}
			}
		});
	}
}