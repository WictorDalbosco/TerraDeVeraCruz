package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class CriacaoController {
	private TelaCriacao tc;
	private Inventario inventario;
	
	public CriacaoController (TelaCriacao tc, Inventario inventario){
		this.tc = tc;
		this.inventario = inventario;
	}
	
	public void inicializaController() {
		ArrayList<Slot> inventario = this.inventario.getInventario();
		for(Slot s : inventario) {
			System.out.println("entrou");
			//criar v�rios Paineis de produtos
			PanelSlot panelS = new PanelSlot();
			PanelSlotController panelPController = new PanelSlotController(panelS, s);
			panelPController.inicializaController();
			tc.addSlotPanel(panelS.getPanel());
		}
		
		
		this.tc.getCriarButton().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				PanelCriar pc = new PanelCriar();
				tc.clean();
				tc.addPanel(pc.getPanel());
				tc.getFrame().repaint();
				PanelCriarController pcc = new PanelCriarController(pc);
				pcc.inicializaController();
			}
		});
		this.tc.getAtualizarItem().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				PanelAtualizar pa = new PanelAtualizar();
				tc.clean();
				tc.addPanel(pa.getPanel());
				tc.getFrame().repaint();
				PanelAtualizarController pac = new PanelAtualizarController(pa);
				pac.inicializaController();
			}
		});
		this.tc.getExcluirButton().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				PanelExcluir pe = new PanelExcluir();
				tc.clean();
				tc.addPanel(pe.getPanel());
				tc.getFrame().repaint();
				PanelExcluirController pec = new PanelExcluirController(pe);
				pec.inicializaController();
			}
		});
		
	}
}
