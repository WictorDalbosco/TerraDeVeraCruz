package Jogo;

import java.util.ArrayList;

public class Inventario {
	private ArrayList<Slot> inventario = new ArrayList();
	
	public void addSlot(Slot slot) {
		inventario.add(slot);
	}
	
	public ArrayList<Slot> getInventario() {
		return inventario;
	}
}
