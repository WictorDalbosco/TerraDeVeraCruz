package Jogo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JToggleButton;
import javax.swing.JScrollBar;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import java.awt.Component;
import javax.swing.ScrollPaneConstants;
import java.awt.GridLayout;
import javax.swing.JLabel;

public class TelaCriacao {

	private JFrame frame;
	private JButton btnCriarButton, btnExcluirButton, btnAtualizarItem;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCriacao window = new TelaCriacao();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaCriacao() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 453, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 437, 361);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		btnCriarButton = new JButton("Criar Item");
		btnCriarButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCriarButton.setBounds(10, 39, 99, 23);
		panel.add(btnCriarButton);
		
		btnExcluirButton = new JButton("Excluir Item");
		btnExcluirButton.setBounds(10, 77, 99, 23);
		panel.add(btnExcluirButton);
		
		btnAtualizarItem = new JButton("Atualizar Item");
		btnAtualizarItem.setBounds(10, 111, 99, 23);
		panel.add(btnAtualizarItem);
		
		panel_1 = new JPanel();
		panel_1.setBounds(119, 39, 300, 100);
		panel.add(panel_1);
		
		panel_2 = new JPanel();
		JScrollPane scrollPane = new JScrollPane(panel_2);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(119, 145, 300, 205);
		panel.add(scrollPane);
		
		
		scrollPane.setViewportView(panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 10));
	}

	public JButton getCriarButton() {
		return btnCriarButton;
	}

	public void setCriarButton(JButton btnCriarButton) {
		this.btnCriarButton = btnCriarButton;
	}

	public JButton getExcluirButton() {
		return btnExcluirButton;
	}

	public void setExcluirButton(JButton btnExcluirButton) {
		this.btnExcluirButton = btnExcluirButton;
	}

	public JButton getAtualizarItem() {
		return btnAtualizarItem;
	}

	public void setAtualizarItem(JButton btnAtualizarItem) {
		this.btnAtualizarItem = btnAtualizarItem;
	}
	
	public void addPanel(JPanel i) {
		panel_1.add(i);
	}
	
	public void addSlotPanel(JPanel i) {
		panel_2.add(i);
	}
	
	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public void removePanel(JPanel i) {
		panel_1.remove(i);
	}

	public void setPanel(JPanel panel) {
		this.panel = panel;
	}
	
	public void clean() {
		panel_1.removeAll();
	}
}
