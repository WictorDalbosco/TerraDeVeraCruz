package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PauseController {
	private PanelPause pause;
	//private Usuario usuario;

	PauseController(PanelPause pause){
		this.pause = pause;
		//this.usuario = usuario;
	}
	
	public void inicializaController() {
		this.pause.getBtnVoltar().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				exclui();				
			}
		});
		this.pause.getBtnConfiguracoes().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {

				TelaConfiguracoes tc = new TelaConfiguracoes();
				
								
			}
		});
	}
	
	public void exclui() {
		System.out.println("ent");
		pause.getPanel().disable();

	}
}