package Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelCriarController {
	private PanelCriar pc;
	
	
	public PanelCriarController(PanelCriar pc) {
		this.pc = pc;
	}
	
	public void inicializaController() {
		this.pc.getCriarItem().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				Slot slotAdd = new Slot(Integer.parseInt(pc.getTextField().getText()),pc.getTextField_1().getText());
				System.out.println(slotAdd.getId());
				System.out.println(slotAdd.getItem());
			}
		});
		
	}
}
