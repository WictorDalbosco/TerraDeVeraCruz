package Jogo;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;

public class PanelSlot {

	private JPanel panel;
	private JButton btnCriarItem;
	private JLabel label,label_1;
	
	public JLabel getLabel() {
		return label;
	}

	public void setLabel(JLabel label) {
		this.label = label;
	}

	public JLabel getLabel_1() {
		return label_1;
	}

	public void setLabel_1(JLabel label_1) {
		this.label_1 = label_1;
	}

	public JPanel getPanel() {
		return panel;
	}

	public void setPanel(JPanel panel) {
		this.panel = panel;
	}
	
	public PanelSlot() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
	
		panel = new JPanel();
		panel.setBounds(0, 0, 300, 115);
		panel.setLayout(null);
		
		JLabel lblId = new JLabel("ID: ");
		lblId.setBounds(10, 14, 46, 14);
		panel.add(lblId);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(10, 45, 46, 14);
		panel.add(lblNome);
		
		btnCriarItem = new JButton("Teste");
		btnCriarItem.setBounds(10, 66, 89, 23);
		panel.add(btnCriarItem);
		
		label = new JLabel("<<num>>");
		label.setFont(new Font("Algerian", Font.PLAIN, 14));
		label.setBounds(66, 14, 135, 14);
		panel.add(label);
		
		label_1 = new JLabel("<<NOME>>");
		label_1.setFont(new Font("Algerian", Font.PLAIN, 14));
		label_1.setBounds(66, 45, 135, 14);
		panel.add(label_1);

	}

}
